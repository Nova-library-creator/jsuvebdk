#include "raymob.h"
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>

/*
    ИГРА: «НАШЕ МАЛЕНЬКОЕ ЛЕТО»
    Полноценная короткая 2D-игра с началом, заданиями и финалом.
    Для шаблона Bigfoot71/raymob: app/src/main/cpp/main.c

    ВАЖНО О ШРИФТЕ:
    Русский текст выводится через шрифт assets/fonts/DejaVuSans.ttf.
    Положите DejaVuSans.ttf в app/src/main/assets/fonts/DejaVuSans.ttf.
    Если файл не найден, игра автоматически покажет английские подписи,
    чтобы не зависать и не падать.
*/

#define SW 960
#define SH 540
#define WORLD_W 1600
#define WORLD_H 900
#define PI 3.14159265358979323846f

typedef enum { SCREEN_TITLE, SCREEN_PLAY, SCREEN_PAUSE, SCREEN_END } Screen;
typedef enum { PARK, TOWN, CAFE, BEACH, HOME } Place;

typedef struct { float x, y; } V2;

typedef struct {
    V2 pos;
    float speed;
    int facing;
} Player;

typedef struct {
    V2 pos;
    const char *nameRu;
    const char *nameEn;
    int kind;
} Person;

static Screen screen = SCREEN_TITLE;
static Place place = PARK;
static Player hero = {{220, 450}, 220.0f, 0};
static Camera2D camera = {0};
static Font ruFont;
static bool hasRuFont = false;

static int quest = 0;
static int flowers = 0;
static bool gotLetter = false;
static bool gotCoffee = false;
static bool gotShell = false;
static bool gotPhoto = false;
static bool talkedPark = false;
static bool talkedCafe = false;
static bool talkedBeach = false;
static bool talkedHome = false;
static bool showDialogue = false;
static int dialoguePage = 0;
static int dialogueId = 0;
static int choice = -1;
static float timeOfDay = 0.0f;
static char toast[128] = "";
static float toastTimer = 0.0f;

static const char *R(const char *ru, const char *en) { return hasRuFont ? ru : en; }

static void Text(const char *ru, const char *en, int x, int y, int size, Color c) {
    const char *s = R(ru, en);
    if (hasRuFont) DrawTextEx(ruFont, s, (Vector2){(float)x,(float)y}, (float)size, 1.0f, c);
    else DrawText(s, x, y, size, c);
}
static int Measure(const char *ru, const char *en, int size) {
    const char *s = R(ru, en);
    if (hasRuFont) return (int)MeasureTextEx(ruFont, s, (float)size, 1.0f).x;
    return MeasureText(s, size);
}
static void Toast(const char *ru, const char *en) {
    snprintf(toast, sizeof(toast), "%s", R(ru,en));
    toastTimer = 2.2f;
}
static float Dist(V2 a, V2 b) {
    float x=a.x-b.x, y=a.y-b.y;
    return sqrtf(x*x+y*y);
}
static bool RectHit(Rectangle r, Vector2 p) { return CheckCollisionPointRec(p,r); }

static void Button(Rectangle r, const char *ru, const char *en, bool active) {
    Vector2 m = GetMousePosition();
    bool hover = RectHit(r,m);
    DrawRectangleRounded(r, 0.22f, 8, active ? (hover ? (Color){255,224,183,255} : (Color){255,238,211,255}) : (Color){80,91,105,230});
    DrawRectangleRoundedLines(r, 0.22f, 8, 2, (Color){105,76,73,255});
    int size = 20;
    int w = Measure(ru,en,size);
    Text(ru,en,(int)(r.x+r.width/2-w/2),(int)(r.y+r.height/2-size/2),size, active ? (Color){83,54,58,255} : RAYWHITE);
}
static bool ButtonPressed(Rectangle r) {
    if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT) && RectHit(r,GetMousePosition())) return true;
    if (GetTouchPointCount()>0) {
        Vector2 p=GetTouchPosition(0);
        if (IsGestureDetected(GESTURE_TAP) && RectHit(r,p)) return true;
    }
    return false;
}
static void Box(int x,int y,int w,int h,Color c) {
    DrawRectangleRounded((Rectangle){(float)x,(float)y,(float)w,(float)h},0.08f,8,c);
    DrawRectangleRoundedLines((Rectangle){(float)x,(float)y,(float)w,(float)h},0.08f,8,2,(Color){91,69,70,230});
}

static void SetPlace(Place p) {
    place=p;
    hero.pos=(V2){220,450};
    if(p==TOWN) hero.pos=(V2){180,450};
    if(p==CAFE) hero.pos=(V2){180,450};
    if(p==BEACH) hero.pos=(V2){180,450};
    if(p==HOME) hero.pos=(V2){180,450};
    camera.target=(Vector2){hero.pos.x,hero.pos.y};
}
static const char *PlaceNameRu(void) {
    switch(place){case PARK:return "Парк";case TOWN:return "Старый город";case CAFE:return "Кафе у окна";case BEACH:return "Тихий пляж";default:return "Наш дом";}
}
static const char *PlaceNameEn(void) {
    switch(place){case PARK:return "Park";case TOWN:return "Old town";case CAFE:return "Window cafe";case BEACH:return "Quiet beach";default:return "Our home";}
}
static void StartDialogue(int id) {
    dialogueId=id; dialoguePage=0; showDialogue=true; choice=-1;
}
static void FinishDialogue(void) {
    showDialogue=false;
    if(dialogueId==1){talkedPark=true; quest=1; gotLetter=true; Toast("Ты нашёл письмо! Теперь зайди в город.","You found the letter! Visit the town.");}
    if(dialogueId==2){talkedCafe=true; quest=2; gotCoffee=true; Toast("Кофе готов. Пора на пляж!","Coffee ready. Time for the beach!");}
    if(dialogueId==3){talkedBeach=true; quest=3; gotPhoto=true; Toast("Вы сделали памятное фото.","You took a keepsake photo.");}
    if(dialogueId==4){talkedHome=true; screen=SCREEN_END;}
}
static const char *DialogueRu(void) {
    static const char *d[5][4]={
        {"","", "", ""},
        {"Привет! Я оставила для тебя маленькое письмо.","В нём написано: «Следуй за тёплым ветром».","Давай прогуляемся по нашему любимому городу?",""},
        {"Я заказала нам какао у окна.","Помнишь, как мы однажды спрятались здесь от дождя?","Возьми стаканчик — впереди нас ждёт море.",""},
        {"Посмотри, какой сегодня красивый закат!","Давай сохраним этот момент на память.","Пусть это будет наше маленькое лето.",""},
        {"Мы прошли весь этот путь вместе.","Спасибо за каждый смешной момент и каждую прогулку.","Это не конец приключения — это наше начало.","С любовью. ❤️"}
    };
    return d[dialogueId][dialoguePage];
}
static const char *DialogueEn(void) {
    static const char *d[5][4]={
        {"","","",""},
        {"Hi! I left a little letter for you.","It says: 'Follow the warm wind.'","Shall we walk through our favourite town?",""},
        {"I ordered hot chocolate by the window.","Remember hiding here from the rain?","Take your cup. The sea is waiting.",""},
        {"Look at this beautiful sunset!","Let's keep this moment as a memory.","This is our little summer.",""},
        {"We walked this whole path together.","Thank you for every laugh and every walk.","This is not the end. It is our beginning.","With love. ❤️"}
    };
    return d[dialogueId][dialoguePage];
}

static void DrawTree(float x,float y) {
    DrawCircle((int)x,(int)y+18,28,(Color){105,72,54,255});
    DrawCircle((int)x,(int)y,43,(Color){54,130,83,255});
    DrawCircle((int)x-20,(int)y+7,27,(Color){67,151,91,255});
    DrawCircle((int)x+22,(int)y+10,25,(Color){48,119,77,255});
}
static void DrawPerson(Person p) {
    DrawCircle((int)p.pos.x,(int)p.pos.y-23,13,(Color){247,203,166,255});
    DrawRectangle((int)p.pos.x-12,(int)p.pos.y-10,24,28,p.kind==1?(Color){226,128,150,255}:(Color){99,130,190,255});
    DrawCircle((int)p.pos.x,(int)p.pos.y-27,14,(Color){91,61,53,255});
    DrawCircle((int)p.pos.x-4,(int)p.pos.y-23,2,(Color){55,45,45,255});
    DrawCircle((int)p.pos.x+4,(int)p.pos.y-23,2,(Color){55,45,45,255});
}
static void DrawPlayer(void) {
    DrawEllipse((int)hero.pos.x,(int)hero.pos.y+8,17,7,(Color){40,55,45,70});
    DrawRectangle((int)hero.pos.x-11,(int)hero.pos.y-19,22,28,(Color){91,145,205,255});
    DrawCircle((int)hero.pos.x,(int)hero.pos.y-28,12,(Color){244,199,159,255});
    DrawRectangle((int)hero.pos.x-12,(int)hero.pos.y-38,24,8,(Color){76,54,49,255});
}
static void DrawFlower(float x,float y,Color c) {
    DrawCircle((int)x,(int)y,5,c);
    DrawCircle((int)x-5,(int)y,4,c); DrawCircle((int)x+5,(int)y,4,c);
    DrawCircle((int)x,(int)y-5,4,c); DrawCircle((int)x,(int)y+5,4,c);
    DrawCircle((int)x,(int)y,3,(Color){255,220,110,255});
}
static void DrawWorld(void) {
    Color grass=(Color){125,181,119,255};
    Color path=(Color){218,194,151,255};
    if(place==PARK) {
        ClearBackground(grass);
        DrawRectangle(0,365,WORLD_W,170,path);
        DrawRectangle(0,390,WORLD_W,120,(Color){231,211,174,255});
        for(int i=0;i<7;i++) DrawTree(120+i*220,150+(i%2)*65);
        for(int i=0;i<7;i++) DrawTree(100+i*220,700-(i%2)*55);
        DrawRectangle(0,0,WORLD_W,45,(Color){92,148,94,255});
        Text("ПАРК","PARK",30,15,22,RAYWHITE);
        if(flowers<1) DrawFlower(430,320,(Color){244,100,145,255});
        if(flowers<2) DrawFlower(720,600,(Color){255,225,100,255});
        if(flowers<3) DrawFlower(1050,300,(Color){180,135,245,255});
        DrawPerson((Person){{1250,455},"Мия","Mia",1});
    } else if(place==TOWN) {
        ClearBackground((Color){184,204,215,255});
        DrawRectangle(0,370,WORLD_W,170,(Color){174,157,139,255});
        for(int i=0;i<6;i++){
            int x=70+i*260;
            DrawRectangle(x,130,175,260,(Color){218,181,148,255});
            DrawRectangle(x+20,165,55,75,(Color){117,165,188,255});
            DrawRectangle(x+100,165,55,75,(Color){117,165,188,255});
            DrawRectangle(x+60,290,55,100,(Color){113,82,71,255});
            DrawTriangle((Vector2){(float)x-15,130},(Vector2){(float)x+87,55},(Vector2){(float)x+190,130},(Color){153,91,83,255});
        }
        DrawRectangle(0,0,WORLD_W,45,(Color){112,130,145,255});
        Text("СТАРЫЙ ГОРОД","OLD TOWN",30,15,22,RAYWHITE);
        DrawCircle(780,470,24,(Color){255,223,140,255});
    } else if(place==CAFE) {
        ClearBackground((Color){197,166,139,255});
        DrawRectangle(0,370,WORLD_W,170,(Color){130,92,74,255});
        DrawRectangle(80,80,1440,270,(Color){232,213,185,255});
        for(int i=0;i<4;i++){
            DrawRectangle(140+i*340,120,250,170,(Color){127,174,188,255});
            DrawLine(265+i*340,120,265+i*340,290,(Color){235,226,206,255});
            DrawLine(140+i*340,205,390+i*340,205,(Color){235,226,206,255});
        }
        DrawRectangle(0,0,WORLD_W,45,(Color){112,76,65,255});
        Text("КАФЕ У ОКНА","WINDOW CAFE",30,15,22,RAYWHITE);
        DrawRectangle(600,450,180,20,(Color){104,66,55,255});
        DrawPerson((Person){{1000,455},"Мия","Mia",1});
    } else if(place==BEACH) {
        ClearBackground((Color){106,183,207,255});
        DrawRectangle(0,250,WORLD_W,650,(Color){235,210,157,255});
        DrawRectangle(0,250,WORLD_W,150,(Color){91,171,201,255});
        for(int i=0;i<9;i++) DrawCircle(100+i*190,340+(i%2)*22,28,(Color){120,193,211,255});
        DrawCircle(1370,130,62,(Color){255,218,133,255});
        DrawRectangle(0,0,WORLD_W,45,(Color){71,144,163,255});
        Text("ТИХИЙ ПЛЯЖ","QUIET BEACH",30,15,22,RAYWHITE);
        if(!gotShell){DrawEllipse(520,610,15,9,(Color){248,240,218,255});DrawLine(520,601,520,619,(Color){190,155,122,255});}
        DrawPerson((Person){{1190,455},"Мия","Mia",1});
    } else {
        ClearBackground((Color){173,145,129,255});
        DrawRectangle(0,0,WORLD_W,WORLD_H,(Color){193,164,144,255});
        DrawRectangle(60,60,1480,780,(Color){232,213,188,255});
        DrawRectangle(120,120,1360,600,(Color){206,184,161,255});
        DrawRectangle(180,180,310,190,(Color){133,171,183,255});
        DrawRectangle(550,560,490,80,(Color){119,83,72,255});
        DrawRectangle(600,490,380,70,(Color){146,102,85,255});
        DrawRectangle(1130,190,210,300,(Color){154,111,87,255});
        DrawRectangle(0,0,WORLD_W,45,(Color){111,77,68,255});
        Text("НАШ ДОМ","OUR HOME",30,15,22,RAYWHITE);
        DrawPerson((Person){{1160,480},"Мия","Mia",1});
    }
    DrawPlayer();
}

static void DrawHud(void) {
    Box(16,54,335,94,(Color){38,48,55,220});
    Text("ЗАДАНИЕ","QUEST",30,65,16,(Color){255,222,170,255});
    const char *ru,*en;
    if(quest==0){ru="Собери 3 цветка в парке";en="Collect 3 flowers in the park";}
    else if(quest==1){ru="Найди Мию в старом городе";en="Find Mia in the old town";}
    else if(quest==2){ru="Зайди в кафе и поговори";en="Visit the cafe and talk";}
    else if(quest==3){ru="Найди ракушку и Мию на пляже";en="Find a shell and Mia on the beach";}
    else {ru="Вернись домой вместе";en="Go home together";}
    Text(ru,en,30,91,17,RAYWHITE);
    if(place==PARK) Text("Цветы: 0/3","Flowers: 0/3",30,120,15,RAYWHITE);
    else if(place==BEACH && !gotShell) Text("Найди ракушку","Find the shell",30,120,15,RAYWHITE);
    Box(SW-178,16,160,44,(Color){38,48,55,205});
    Text(PlaceNameRu(),PlaceNameEn(),SW-166,27,17,RAYWHITE);
}

static void UpdatePlayer(float dt) {
    V2 dir={0,0};
    if(IsKeyDown(KEY_LEFT)||IsKeyDown(KEY_A)) dir.x-=1;
    if(IsKeyDown(KEY_RIGHT)||IsKeyDown(KEY_D)) dir.x+=1;
    if(IsKeyDown(KEY_UP)||IsKeyDown(KEY_W)) dir.y-=1;
    if(IsKeyDown(KEY_DOWN)||IsKeyDown(KEY_S)) dir.y+=1;
    if(GetTouchPointCount()>0) {
        Vector2 t=GetTouchPosition(0);
        if(t.x<SW*0.42f && t.y>SH*0.55f) {
            if(t.x<SW*0.20f) dir.x=-1;
            else if(t.x<SW*0.34f) dir.x=1;
            else if(t.y<SH*0.78f) dir.y=-1;
            else dir.y=1;
        }
    }
    if(IsGamepadAvailable(0)) {
        dir.x+=GetGamepadAxisMovement(0,GAMEPAD_AXIS_LEFT_X);
        dir.y+=GetGamepadAxisMovement(0,GAMEPAD_AXIS_LEFT_Y);
    }
    float len=sqrtf(dir.x*dir.x+dir.y*dir.y);
    if(len>0.01f){dir.x/=len;dir.y/=len;hero.pos.x+=dir.x*hero.speed*dt;hero.pos.y+=dir.y*hero.speed*dt;}
    hero.pos.x=Clamp(hero.pos.x,35,WORLD_W-35);
    hero.pos.y=Clamp(hero.pos.y,90,WORLD_H-35);
    if(place==PARK) {
        V2 f[3]={{430,320},{720,600},{1050,300}};
        for(int i=0;i<3;i++) if(flowers<=i && Dist(hero.pos,f[i])<38) {
            flowers++;
            Toast("Ты собрал цветок!","You picked a flower!");
            if(flowers==3) Toast("Все цветы собраны. Найди Мию!","All flowers collected. Find Mia!");
        }
        if(flowers>=3 && hero.pos.x>WORLD_W-55) SetPlace(TOWN);
    }
    if(place==TOWN && hero.pos.x>WORLD_W-55) SetPlace(CAFE);
    if(place==TOWN && hero.pos.x<45) SetPlace(PARK);
    if(place==CAFE && hero.pos.x<45) SetPlace(TOWN);
    if(place==CAFE && hero.pos.x>WORLD_W-55 && gotCoffee) SetPlace(BEACH);
    if(place==BEACH && hero.pos.x<45) SetPlace(CAFE);
    if(place==BEACH && hero.pos.x>WORLD_W-55 && gotPhoto) SetPlace(HOME);
    if(place==HOME && hero.pos.x<45) SetPlace(BEACH);
    if(place==BEACH && !gotShell && Dist(hero.pos,(V2){520,610})<38) {
        gotShell=true; Toast("Ты нашёл красивую ракушку!","You found a pretty shell!");
    }
    camera.target=(Vector2){hero.pos.x,hero.pos.y};
    camera.offset=(Vector2){SW/2.0f,SH/2.0f};
    camera.rotation=0;
    camera.zoom=0.72f;
}

static void Interact(void) {
    if(showDialogue) {
        if(dialogueId==3 && dialoguePage==1 && choice<0) {
            if(ButtonPressed((Rectangle){SW/2-210,SH-110,190,52})) choice=0;
            if(ButtonPressed((Rectangle){SW/2+20,SH-110,190,52})) choice=1;
            if(choice>=0) dialoguePage++;
            return;
        }
        dialoguePage++;
        if(dialoguePage>=4 || (dialogueId!=4 && dialoguePage>=3)) FinishDialogue();
        return;
    }
    if(place==PARK && flowers>=3 && Dist(hero.pos,(V2){1250,455})<100 && !talkedPark) StartDialogue(1);
    else if(place==TOWN && Dist(hero.pos,(V2){780,470})<110 && !talkedPark) StartDialogue(1);
    else if(place==CAFE && Dist(hero.pos,(V2){1000,455})<110 && !talkedCafe) StartDialogue(2);
    else if(place==BEACH && Dist(hero.pos,(V2){1190,455})<110 && gotShell && !talkedBeach) StartDialogue(3);
    else if(place==HOME && Dist(hero.pos,(V2){1160,480})<110 && gotPhoto && !talkedHome) StartDialogue(4);
    else Toast("Подойди ближе к персонажу или предмету.","Move closer to a person or item.");
}

static void DrawDialogue(void) {
    Box(35,SH-190,SW-70,165,(Color){35,39,48,245});
    Text(dialogueId==4?"ПОСЛЕДНЯЯ СЦЕНА":"РАЗГОВОР",dialogueId==4?"FINAL SCENE":"DIALOGUE",60,SH-176,15,(Color){255,211,160,255});
    const char *ru=DialogueRu(), *en=DialogueEn();
    Text(ru,en,60,SH-140,20,RAYWHITE);
    if(dialogueId==3 && dialoguePage==1 && choice<0) {
        Button((Rectangle){SW/2-210,SH-110,190,52},"Да, давай!","Yes, let's!",true);
        Button((Rectangle){SW/2+20,SH-110,190,52},"Конечно!","Of course!",true);
    } else {
        Button((Rectangle){SW-220,SH-83,155,42},dialogueId==4?"Завершить":"Далее",dialogueId==4?"Finish":"Next",true);
    }
}

static void DrawTouchControls(void) {
    Color c=(Color){35,48,55,115};
    DrawCircle(82,SH-85,33,c); DrawCircle(82,SH-145,26,c); DrawCircle(22,SH-85,26,c); DrawCircle(142,SH-85,26,c);
    Text("↑","^",72,SH-162,24,RAYWHITE); Text("←","<",12,SH-97,24,RAYWHITE); Text("→",">",132,SH-97,24,RAYWHITE); Text("↓","v",72,SH-102,24,RAYWHITE);
    Button((Rectangle){SW-145,SH-110,115,70},"ДЕЙСТВИЕ","ACTION",true);
}

int main(void) {
    InitWindow(0,0,"Наше маленькое лето");
    SetTargetFPS(60);
    SetExitKey(KEY_NULL);
    ruFont=LoadFont("fonts/DejaVuSans.ttf");
    hasRuFont=(ruFont.texture.id!=0);
    if(hasRuFont) SetTextureFilter(ruFont.texture,TEXTURE_FILTER_BILINEAR);

    while(!WindowShouldClose()) {
        float dt=GetFrameTime();
        if(dt>0.05f) dt=0.05f;
        timeOfDay+=dt;
        if(toastTimer>0) toastTimer-=dt;

        if(screen==SCREEN_TITLE) {
            if(IsKeyPressed(KEY_ENTER)||IsMouseButtonPressed(MOUSE_BUTTON_LEFT)||GetTouchPointCount()>0) screen=SCREEN_PLAY;
        } else if(screen==SCREEN_PLAY) {
            if(!showDialogue) UpdatePlayer(dt);
            if(showDialogue) {
                bool pressed = IsKeyPressed(KEY_E) || IsKeyPressed(KEY_SPACE);
                if(dialogueId==3 && dialoguePage==1 && choice<0) {
                    pressed = pressed ||
                        ButtonPressed((Rectangle){SW/2-210,SH-110,190,52}) ||
                        ButtonPressed((Rectangle){SW/2+20,SH-110,190,52});
                } else {
                    pressed = pressed || ButtonPressed((Rectangle){SW-220,SH-83,155,42});
                }
                if(pressed) Interact();
            } else if(IsKeyPressed(KEY_E)||IsKeyPressed(KEY_SPACE)||ButtonPressed((Rectangle){SW-145,SH-110,115,70})) {
                Interact();
            }
            if(IsKeyPressed(KEY_ESCAPE)) screen=SCREEN_PAUSE;
        } else if(screen==SCREEN_PAUSE) {
            if(IsKeyPressed(KEY_ESCAPE)||IsKeyPressed(KEY_ENTER)||ButtonPressed((Rectangle){SW/2-120,SH/2+30,240,60})) screen=SCREEN_PLAY;
        } else if(screen==SCREEN_END) {
            if(IsKeyPressed(KEY_ENTER)||ButtonPressed((Rectangle){SW/2-130,SH-130,260,60})) {
                screen=SCREEN_TITLE; place=PARK; hero.pos=(V2){220,450}; quest=0; flowers=0;
                gotLetter=gotCoffee=gotShell=gotPhoto=false;
                talkedPark=talkedCafe=talkedBeach=talkedHome=false;
            }
        }

        BeginDrawing();
        if(screen==SCREEN_TITLE) {
            ClearBackground((Color){92,145,139,255});
            DrawCircle(790,115,90,(Color){255,220,153,255});
            for(int i=0;i<8;i++) DrawFlower(110+i*100,390+(i%3)*22,(Color){245,135,157,255});
            Text("НАШЕ","OUR",SW/2-95,105,42,RAYWHITE);
            Text("МАЛЕНЬКОЕ ЛЕТО","LITTLE SUMMER",SW/2-205,155,42,(Color){255,225,183,255});
            Text("Небольшое приключение о тёплых воспоминаниях","A little adventure about warm memories",SW/2-245,235,18,RAYWHITE);
            Button((Rectangle){SW/2-135,330,270,65},"НАЧАТЬ ИГРУ","START GAME",true);
            Text("Управление: экранные кнопки или WASD","Controls: touch buttons or WASD",SW/2-205,430,17,RAYWHITE);
        } else if(screen==SCREEN_PLAY) {
            BeginMode2D(camera);
            DrawWorld();
            EndMode2D();
            DrawHud();
            DrawTouchControls();
            if(showDialogue) DrawDialogue();
            if(toastTimer>0) {
                int tw=Measure(toast,toast,18);
                Box(SW/2-tw/2-20,SH-225,tw+40,38,(Color){37,48,54,225});
                Text(toast,toast,SW/2-tw/2,SH-216,18,RAYWHITE);
            }
            if(IsKeyPressed(KEY_ESCAPE)) screen=SCREEN_PAUSE;
        } else if(screen==SCREEN_PAUSE) {
            ClearBackground((Color){47,58,64,255});
            Text("ПАУЗА","PAUSED",SW/2-80,145,38,RAYWHITE);
            Button((Rectangle){SW/2-120,SH/2+30,240,60},"ПРОДОЛЖИТЬ","RESUME",true);
        } else {
            ClearBackground((Color){77,125,124,255});
            DrawCircle(SW/2,130,68,(Color){255,220,151,255});
            Text("НАШЕ МАЛЕНЬКОЕ ЛЕТО","OUR LITTLE SUMMER",SW/2-235,235,32,RAYWHITE);
            Text("Спасибо за это приключение.","Thank you for this adventure.",SW/2-170,300,21,RAYWHITE);
            Text("Самые тёплые истории только начинаются. ❤️","The warmest stories are just beginning. ❤️",SW/2-250,340,18,(Color){255,226,191,255});
            Button((Rectangle){SW/2-130,SH-130,260,60},"СЫГРАТЬ СНОВА","PLAY AGAIN",true);
        }
        EndDrawing();
    }
    if(hasRuFont) UnloadFont(ruFont);
    CloseWindow();
    return 0;
}
