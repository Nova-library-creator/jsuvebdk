[app]

title = Spootix
package.name = spootix
package.domain = org.spootix

source.dir = .
source.include_exts = py,json,png,jpg,kv

version = 0.9.0

requirements = python3,kivy,plyer

orientation = portrait
fullscreen = 0

android.permissions = INTERNET,RECORD_AUDIO

android.api = 35
android.minapi = 24

android.archs = arm64-v8a

android.accept_sdk_license = True

[buildozer]

log_level = 2
warn_on_root = 1