print("Проверка голосовой системы Spootix")
print("--------------------------------")

try:
    from jnius import autoclass

    print("[OK] Pyjnius подключён")

    SpeechRecognizer = autoclass(
        "android.speech.SpeechRecognizer"
    )

    print("[OK] Android SpeechRecognizer доступен")

    Intent = autoclass("android.content.Intent")
    print("[OK] Android Intent доступен")

    try:
        Activity = autoclass(
            "org.kivy.android.PythonActivity"
        )
        print("[OK] Kivy Activity найдена")

    except Exception as e:
        print("[!] Kivy Activity не найдена:")
        print(e)

except Exception as e:
    print("[ОШИБКА]")
    print(str(e))

print("--------------------------------")
print("Проверка завершена")