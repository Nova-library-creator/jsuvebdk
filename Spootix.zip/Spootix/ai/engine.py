def get_ai_response(prompt: str) -> str:
    return 'Онлайн-ИИ ещё не подключён. Добавим его на следующем этапе.'
