import subprocess
import webbrowser
from urllib.parse import quote_plus

def handle_command(text: str):
    command = text.lower().strip()
    if command in {'открой блокнот', 'запусти блокнот'}:
        subprocess.Popen(['notepad.exe'])
        return 'Открываю Блокнот.'
    if command in {'открой калькулятор', 'запусти калькулятор'}:
        subprocess.Popen(['calc.exe'])
        return 'Открываю Калькулятор.'
    if command in {'открой браузер', 'запусти браузер'}:
        webbrowser.open('https://www.google.com')
        return 'Открываю браузер.'
    prefix = 'найди в интернете '
    if command.startswith(prefix):
        query = text[len(prefix):].strip()
        if query:
            webbrowser.open('https://www.google.com/search?q=' + quote_plus(query))
            return f'Ищу в интернете: {query}'
        return 'Напиши, что именно нужно найти.'
    return None
