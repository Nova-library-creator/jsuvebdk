import json
from datetime import datetime
from pathlib import Path

MEMORY_FILE = Path(__file__).resolve().parents[1] / 'data' / 'history.json'

def remember_exchange(user_text: str, assistant_text: str):
    MEMORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    try:
        history = json.loads(MEMORY_FILE.read_text(encoding='utf-8')) if MEMORY_FILE.exists() else []
    except (json.JSONDecodeError, OSError):
        history = []
    history.append({'time': datetime.now().isoformat(timespec='seconds'),
                    'user': user_text, 'assistant': assistant_text})
    history = history[-500:]
    MEMORY_FILE.write_text(json.dumps(history, ensure_ascii=False, indent=2), encoding='utf-8')
