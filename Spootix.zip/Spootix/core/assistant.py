from core.commands import handle_command
from core.config import load_settings
from core.memory import remember_exchange

class Assistant:
    def __init__(self):
        self.settings = load_settings()

    def respond(self, text: str) -> str:
        command_result = handle_command(text.strip())
        if command_result is not None:
            return command_result
        lowered = text.strip().lower()
        if lowered in {'привет', 'привет спутик', 'здравствуй', 'хай'}:
            answer = 'Привет! Я на месте. Чем займёмся?'
        elif lowered in {'помощь', 'команды', 'help'}:
            answer = ('Пока я умею открывать Блокнот, Калькулятор и браузер. '
                      'Также можно спросить «как дела?» или «кто ты?». '
                      'Голос и ИИ подключим следующими этапами.')
        elif lowered in {'как дела?', 'как дела'}:
            answer = 'Отлично! Готов помогать. А у тебя что нового?'
        elif lowered in {'кто ты?', 'кто ты'}:
            answer = 'Я Spootix — твой собственный голосовой помощник. Это моя первая версия.'
        elif lowered in {'выход', 'exit', 'quit'}:
            answer = 'До встречи!'
        else:
            answer = ('Я пока не подключён к онлайн-ИИ и не знаю ответа. '
                      'Подключим интеллект на следующем этапе.')
        remember_exchange(text, answer)
        return answer
