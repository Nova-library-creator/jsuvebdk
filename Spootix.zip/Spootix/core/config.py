import json
from pathlib import Path

SETTINGS_FILE = Path(__file__).resolve().parents[1] / 'settings' / 'config.json'
DEFAULT_SETTINGS = {
    'interface_language': 'ru',
    'assistant_language': 'ru',
    'wake_phrase': 'Привет, Спутик',
    'voice_enabled': False,
    'online_ai_enabled': False,
    'theme': 'dark'
}

def load_settings():
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not SETTINGS_FILE.exists():
        save_settings(DEFAULT_SETTINGS)
    try:
        data = json.loads(SETTINGS_FILE.read_text(encoding='utf-8'))
        return {**DEFAULT_SETTINGS, **data}
    except (json.JSONDecodeError, OSError):
        save_settings(DEFAULT_SETTINGS)
        return DEFAULT_SETTINGS.copy()

def save_settings(settings):
    SETTINGS_FILE.parent.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(json.dumps(settings, ensure_ascii=False, indent=4), encoding='utf-8')
