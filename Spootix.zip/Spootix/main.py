import json
from pathlib import Path

from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.utils import escape_markup

from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView

try:
    from plyer import tts
    TTS_AVAILABLE = True
except ImportError:
    TTS_AVAILABLE = False


class SpootixApp(App):

    def build(self):
        Window.clearcolor = (0.035, 0.045, 0.08, 1)

        self.data_dir = Path(self.user_data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self.history_file = self.data_dir / "history.json"
        self.facts_file = self.data_dir / "facts.json"

        self.history = self.load_data(self.history_file, [])
        self.facts = self.load_data(self.facts_file, [])

        root = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(10)
        )

        title = Label(
            text="[b]S P O O T I X[/b]",
            markup=True,
            font_size="28sp",
            size_hint_y=None,
            height=dp(65)
        )

        root.add_widget(title)

        self.scroll = ScrollView()

        self.chat = Label(
            text="",
            markup=True,
            font_size="17sp",
            halign="left",
            valign="top",
            size_hint_y=None
        )

        self.chat.bind(texture_size=self.update_size)

        self.scroll.add_widget(self.chat)
        root.add_widget(self.scroll)

        bottom = BoxLayout(
            size_hint_y=None,
            height=dp(55),
            spacing=dp(8)
        )

        self.input = TextInput(
            hint_text="Напиши сообщение...",
            multiline=False,
            font_size="17sp"
        )

        self.input.bind(on_text_validate=self.send)

        button = Button(
            text="Отправить",
            size_hint_x=0.35
        )

        button.bind(on_press=self.send)

        bottom.add_widget(self.input)
        bottom.add_widget(button)

        root.add_widget(bottom)

        self.refresh_chat()

        return root

    def load_data(self, path, default):
        try:
            if path.exists():
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                if isinstance(data, type(default)):
                    return data

        except Exception as error:
            print("Ошибка загрузки:", error)

        return default

    def save_data(self, path, data):
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(
                    data,
                    f,
                    ensure_ascii=False,
                    indent=4
                )

        except Exception as error:
            print("Ошибка сохранения:", error)

    def update_size(self, instance, size):
        self.chat.height = size[1] + dp(20)
        self.chat.text_size = (self.chat.width, None)

    def refresh_chat(self):
        lines = []

        if not self.history:
            lines.append(
                "[b]Спутик:[/b]\nПривет! Я снова на связи."
            )

        for item in self.history[-200:]:
            role = item.get("role", "")
            message = escape_markup(item.get("text", ""))

            if role == "user":
                lines.append("[b]Ты:[/b]\n" + message)

            elif role == "assistant":
                lines.append("[b]Спутик:[/b]\n" + message)

        self.chat.text = "\n\n".join(lines)

        Clock.schedule_once(
            lambda dt: setattr(self.scroll, "scroll_y", 0),
            0.1
        )

    def add_message(self, role, text):
        self.history.append({
            "role": role,
            "text": text
        })

        self.history = self.history[-200:]

        self.save_data(self.history_file, self.history)
        self.refresh_chat()

    def get_answer(self, message):
        command = message.lower().strip()

        if command.startswith("запомни:"):
            fact = message[len("запомни:"):].strip()

            if not fact:
                return "Напиши, что именно мне запомнить."

            if fact not in self.facts:
                self.facts.append(fact)
                self.save_data(self.facts_file, self.facts)

            return "Хорошо! Я сохранил это в памяти."

        if command == "что ты помнишь?":
            if not self.facts:
                return "Пока моя память пуста."

            result = "\n".join(
                "• " + fact for fact in self.facts
            )

            return "Вот что я помню:\n" + result

        if command == "привет":
            return "Привет! Рад тебя видеть!"

        if command == "кто ты":
            return "Я Спутик — твой персональный помощник!"

        if command == "как дела":
            return "Всё отлично! Готов продолжать работу!"

        if command == "сколько фактов ты помнишь?":
            return "Я помню фактов: " + str(len(self.facts))

        return "Я получил твоё сообщение! Мы постепенно развиваем мои возможности."

    def speak(self, text):
        if not TTS_AVAILABLE:
            print("TTS недоступен.")
            return

        try:
            tts.speak(text)
        except Exception as error:
            print("Ошибка голосового ответа:", error)

    def send(self, instance):
        message = self.input.text.strip()

        if not message:
            return

        self.input.text = ""

        self.add_message("user", message)

        answer = self.get_answer(message)

        self.add_message("assistant", answer)

        self.speak(answer)


if __name__ == "__main__":
    SpootixApp().run()