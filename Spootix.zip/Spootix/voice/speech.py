def speak(text: str):
    """Озвучивание через необязательную библиотеку pyttsx3."""
    try:
        import pyttsx3
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()
    except ImportError:
        print('[Голос не подключён: установи pyttsx3]')
    except Exception as error:
        print(f'[Не удалось озвучить текст: {error}]')
