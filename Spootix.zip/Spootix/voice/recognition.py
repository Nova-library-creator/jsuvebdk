def listen_once(language='ru-RU'):
    """Распознаёт одну фразу; нужны SpeechRecognition и PyAudio."""
    try:
        import speech_recognition as sr
    except ImportError as exc:
        raise RuntimeError('Распознавание пока не установлено. Настроим микрофон отдельно.') from exc
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print('Слушаю...')
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        audio = recognizer.listen(source, timeout=5, phrase_time_limit=8)
    return recognizer.recognize_google(audio, language=language)
